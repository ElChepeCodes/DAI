#%%
#Bruno Vitte
#José Luis Gutiérrez
import pyodbc
import pandas as pd

def conecta(nombreBd):
    direccion_servidor = 'DESKTOP-I4BI3PH'
    try:
        conexion = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + 
    direccion_servidor+';DATABASE='+nombreBd+';Trusted_Connection=yes;')
        print("\n"*2)
        print("conexión exitosa")
        return conexion
    except Exception as e:
        print("Ocurrió un error al conectar a SQL Server: ", e)

def inserta(con, table, tit, y):
    con.execute("insert into " + table +" (titulo, year) values (\'"+tit+"\',"+str(y)+")")
    con.commit()
    print("inserta")

def delete(con, table, tit):
    query = "delete from "+ table + " where titulo = \'" + tit +"\'"
    con.execute(query)
    con.commit()
    print("delete")


conCine = conecta("baseCine")
#obtener las peliculas que empiezen con A
try:
    with conCine.cursor() as cursor:
        query = "select * from peliculas where titulo like \'A%\'"
        cursor.execute(query)
        pelis = cursor.fetchall()
        for p in pelis:
            print(p)
except Exception as e:
    print ("Error al consultar las peliculas que empiezan con p: "+e)

#try:
    #with conCine.cursor() as cursor:
        #inserta (conCine, "peliculas", "Shrek 2", 2004)
        #inserta (conCine, "peliculas", "Bee Movie", 2007)
        #delete (conCine, "peliculas", "Pulp Fiction")
        
#except Exception as e:
 #   print("Error: " + str(e))
#pandas
try:
    with conCine.cursor() as cursor:
        cursor.execute("select * from peliculas")
        info = cursor.fetchall()
        dfPelis = pd.DataFrame(info, columns=["Id","Titulo", "Año"])
        
        print (dfPelis)
except Exception as e:
    print ("Error: " + str(e))

#en que año salieron mas peliculas de las que hay en catalogo?

#%%