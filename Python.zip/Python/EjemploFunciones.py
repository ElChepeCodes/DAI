def suma (a,b):
    return a + b
def multRara(a,b):
    return a*2 + b
def suma2(a=1, b=None):
    if b == None:
        return a
def saludar(idioma):
    def esp():
        print('hola')
    def ing():
        print('hello')
    def fran():
        print('salut')
    idiomaFun={'es':esp, 'in':ing, 'fr':fran}
    return idiomaFun[idioma]

resta = lambda x,y:x-y

def cubo(x):
    return x**3
lista = [1,2,3,4,5]

def lee(nombre):
    id = open(nombre, 'r')
    contenido = id.read()
    listaRes = contenido.split('\n')
    id.close
    return listaRes
"""

print(list(map(cubo,lista)))
print ([cubo(elem) for elem in lista])

from functools import reduce
nums = [47,11,42,13]
result = reduce (lambda x,y:x+y, nums)
print (result)
"""