import EjemploFunciones
"""
print (EjemploFunciones.suma(2,3))
print (EjemploFunciones.multRara(2,3))
print (EjemploFunciones.multRara(b = 2, a = 3))
EjemploFunciones.saludar('fr')()
print (EjemploFunciones.resta(110,10))
"""
#llamar lectura del archivo
lis = EjemploFunciones.lee('MuchasCURPs.csv')
print (len(lis))