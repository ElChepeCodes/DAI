#%%
import datetime
from dateutil.relativedelta import relativedelta
from matplotlib import pyplot as plt

def leeArchivo(nombre):#metodo para leer el archivo
    id = open(nombre, 'r')
    contenido = id.read()
    lista = contenido.split('\n')
    id.close
    return lista

def generos(nomArch):#respuesta al ejercicio 1
    datos = leeArchivo(nomArch)
    h = 0
    f = 0
    for x in datos:
        if x[10] == 'H':
            h+=1
        else:
            f+=1
    l = len(datos)
    return {'H':(h / l) * 100, 'M':(f / l) * 100}

def nacidosPorMes(nomArch):#respuesta al ejercicio 2
    datos = leeArchivo(nomArch)
    meses = [0,0,0,0,0,0,0,0,0,0,0,0,0]
    for x in datos:
        mStr = ""
        mStr += x[6] + x[7]
        mes = int(mStr)
        meses[mes] += 1
    res = {'Enero': meses[1], 'Febrero': meses[2], 'Marzo': meses[3], 'Abril': meses[4], 'Mayo': meses[5], 'Junio': meses[6], 'Julio': meses[7], 'Agosto': meses[8], 'Septiembre': meses[9], 'Octubre': meses[10], 'Noviembre': meses[11], 'Diciembre': meses[12]}
    return res

def nacidosPorEstado(nomArch):#respuesta al ejercicio 3
    datos = leeArchivo(nomArch)
    res = {}
    for x in datos:
        edo = ''
        edo += x[11] + x [12]
        if edo in res:
            res[edo] += 1
        else:
            res[edo] = 1
    return res

def generoPorEstado(nomArch):#problema 1 pregunta 4
    datos = leeArchivo(nomArch)
    edos = {}
    for x in datos:
        edo =''
        edo += x[11] + x [12]
        genero = x[10]
        if edo in edos:
            edos[edo][genero] += 1
        else:
            edos[edo] = {'M':0, 'H':0}
    for n in edos:
        total = edos[n]['M'] + edos[n]['H']
        edos[n]['M'] = edos[n]['M'] * 100 / total
        edos[n]['H'] = edos[n]['H'] * 100 / total
    return edos

def mayoresDeEdad(nomArch):#problema 2 pregunta 4
    datos = leeArchivo(nomArch)
    edades = {'MayoresDeEdad':0, 'MenoresDeEdad':0}
    fecha = datetime.date.today()
    anio = fecha.year
    for x in datos:
        an = '' + x[4] + x[5]
        an = int(an)        
        if an > anio - 2000:
            an += 1900
        else:
            an += 2000
        dia = '' + x[8] + x[9]
        dia = int(dia)
        mes = '' + x[6] + x[7]
        mes = int(mes)
        if mes == 2 and dia > 28:
            mes += 1     
        try:
            dat = datetime.date(an, mes, dia)
            dif = relativedelta(fecha, dat).years
            if dif < 18:                
                edades['MenoresDeEdad'] +=1
            else:
                edades['MayoresDeEdad'] +=1
        except:
            print('Error en la fecha ', dia, mes, an)
    totales = edades['MenoresDeEdad'] + edades['MayoresDeEdad'] 
    edades['MenoresDeEdad'] = edades['MenoresDeEdad'] * 100 / totales
    edades['MayoresDeEdad'] = edades['MayoresDeEdad'] * 100 / totales
    return edades

def graficaEdades(nomArch):#problema 3 pregunta 4
    datos = leeArchivo(nomArch)
    edades = {}
    fecha = datetime.date.today()
    anio = fecha.year
    for x in datos:
        an = '' + x[4] + x[5]
        an = int(an)        
        if an > anio - 2000:
            an += 1900
        else:
            an += 2000
        dia = '' + x[8] + x[9]
        dia = int(dia)
        mes = '' + x[6] + x[7]
        mes = int(mes)
        if mes == 2 and dia > 28:
            mes += 1
        dat = datetime.date(an, mes, dia)
        ed = relativedelta(fecha, dat).years
        if ed in edades:
            edades[ed] +=1
        else:
            edades[ed] = 1
    plt.bar(range(len(edades)), list(edades.values()), align='center')
    plt.show()

def graficaEdos(nomArch):#problema 4 pregunta 4
    datos = leeArchivo(nomArch)
    edos = {}
    for x in datos:
        edo =''
        edo += x[11] + x [12]
        if edo in edos:
            edos[edo] += 1
        else:
            edos[edo] = 1
    plt.pie([float(v) for v in edos.values()], labels=[str(k) for k in edos.keys()],
           autopct=None)
    plt.show()

#codigo de pruebas
print ('pruebas con el archivo \'CURP_A.csv\'')
nomArch = 'CURP_A.csv'
print (generos(nomArch))
print (nacidosPorMes(nomArch))
print (nacidosPorEstado(nomArch))
print (generoPorEstado(nomArch))
print (mayoresDeEdad(nomArch))
graficaEdades(nomArch)
graficaEdos(nomArch)

print ('pruebas con el archivo \'MuchasCURPs.csv\'')
nomArch = 'MuchasCURPs.csv'
print (generos(nomArch))
print (nacidosPorMes(nomArch))
print (nacidosPorEstado(nomArch))
print (generoPorEstado(nomArch))
print (mayoresDeEdad(nomArch))
graficaEdades(nomArch)
graficaEdos(nomArch)



# %%
