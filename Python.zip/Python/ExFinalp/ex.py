#%%
lista = ['silla', 'mesa', 3, 25, 9.72, 'pizarron', 1]
lista1 = []
lista2 = []
cont = 0
for x in lista:
    if not isinstance(x, int):
        lista2.append(x)
    
    if (isinstance(x, str)):
            lista1.append(x)
            cont += x.count('a')
lista3 = lista[:lista.index(9.72)]
print(lista1)
print(lista2)
print(lista3)
print(cont)

def elimina(l, i):
    if i%2 == 0:
        while(i in l):
            l[l.index(i)] = i*i
    else:
        while(i in l):
            l.remove(i)
l =[1,1,1,2,2,2,2]

elimina(l,1)
elimina(l,2)
print(l)

import pandas as pd
nombres = ['Firulais', 'Pepe Wicho', 'Fiona', 'Blanca']
curp = ['ASD091', 'ESD7NA', 'OOL123', 'ASD091']
raza = ['Dalmata', 'Desconocido', 'Schnauser', 'Labrador']
edad = [13, 5, 2, 7]
d ={'nombres':nombres, 'CURPdueño':curp, "raza":raza, "edad":edad}
df = pd.DataFrame(d)

r1 = df.where(df['CURPdueño'] == 'ASD091')
print(r1)

arch = pd.read_csv('C:/Users/jlgut/Documents/ITAM/Programacion/DAI/Python/ExFinalp/auto.csv')
res1 = arch.where(arch['IdAge'] == 202)
res1 = res1.dropna(thresh = 1)
arch['15%'] = arch['PrecioTotal'] * .15
#%%