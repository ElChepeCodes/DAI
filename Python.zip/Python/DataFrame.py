#%%
import pandas as pd
import numpy as np
#CRUD
#crear un dataframe desde un diccionario
datos = {   'nombre':['Diego', 'Sebastian', 'Luisa'], 'Calificaciones':['10',np.nan,'9']
            ,'Deportes':['football', 'N/A', 'tennis'], 'Materias':['DAI', 'ap', 'ap']}
#convertir el diccionario en un DataFrame
df = pd.DataFrame(datos)
print (df)
print (df.info())

data = [1,2,3,4,5]
df1 = pd.DataFrame(data)
print (df1)

nuevo = pd.DataFrame(datos)
nuevo = nuevo.replace(np.nan, '0')
print (nuevo)

data = [['Alex',12],['Bob',12],['Pedro',15]]
df2 = pd.DataFrame(data,columns=['Nombre', 'Edad'], dtype=float)
print (df2)


url = ('https://raw.github.com/pandas-dev/pandas/master/pandas/tests/data/tips.csv')
tips = pd.read_csv(url)
print (tips.head())
print (tips.shape())


#Select * from tips LIMIT 5 
tips.head(5)
#Select total_bill, cmoker, time from tips limit 5
tips[['total_bill'], ['bill'], ['smoker'], ['time']].head(5)


#select * from tips where time = 'Dinner' limit 5
tips[tips['time']=='Dinner'].head(5)
#lo mismo paso a paso
is_dinner = tips['time'] == 'Dinner'
is_dinner.value_counts()
tips[is_dinner].head(5)

#and & or |
#select * from tips where time='Dinner' and tip>5.0
tips[(tips['time'] == 'Dinner') & (tips['tip'] > 5.0)]

# datos nulos -->pd.NaA
# is Null? --> isna()
# is !Null? -->notna()
#.agg para hacer operaciones
tips.groupby('day').agg({'tip':np.mean(), 'day':np.size})

#select smoker, day, count(*) from tips group by smoker, dat
tips.groupby(['smoker', 'day']).agg({'tip':[np.size, np.mean()]})

#para hacer un inner join pd.merge(df1, df2, on ='key', how='left/right/outer')--left/right/full join
#para hacer union pd.concat([df1,df2])
#%%