#%%
"""
Series con Pandas
unidimensional -- coniene datos de cualquier tipo
pandas.Series(data, index, dtype, copy)
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
#crear una serie vacia
s = pd.Series()
print (s)
#crear una serie de un arreglo con indices predeterminados
data = np.array(['a','b','c','d'])
sa = pd.Series(data)
print (data)
print (sa)
#crear una serie pero con indices dados
data = np.array(['a','b','c','d'])
sai = pd.Series(data, index=[100,200,300,400])
print (sai)
#crear una serie desde un diccionario
data = {'a':0, 'b':1, 'c':2}
sd = pd.Series(data)
print (sd)
#nota el orden del indice existe y el elamento que falta se llena con NaN (no es un numero)
data = data = {'a':0,'b':1,'c':2}
sd2 = pd.Series(data, index=['a','c','b','d'])
print(sd2)
#crear una serie con un escalar
se = pd.Series(5,index=range(10))
print (se)
#CRUD(Create Read Update Delete)
#para accesar los datos de una serie, se hace a traves de la posicion
sEjemplo = pd.Series([1,2,3,4,5], index=['a','b','c','d','e'])
print (sEjemplo)
print (sEjemplo[0])
print (sEjemplo['a'])
#conserva el indice numerico pero tambien puede funcionar como diccionario
print ('hola')
print (sEjemplo.iloc[0])#por posicion
print ('hola')
print (sEjemplo.loc['a'])#por etiqueta


#Update
sEjemplo['a'] = 100
print(sEjemplo)

#Delete
del(sEjemplo['a'])
print (sEjemplo)

#metodos de las series
sEjemplo2 = pd.Series([1,2,3,4,5], index=['a','b','c','d','e'])
print (sEjemplo2)

print (sEjemplo2.count())#cuenta cuantos elementos hay en total en la serie
print (sEjemplo2.value_counts())#cuenta cuantos elementos hay en vada uno de los valores
print (sEjemplo2.unique())#regresa una lista con los valores unicos

#estadisticas
print (sEjemplo2.mean())#
print (sEjemplo2.median())#
print (sEjemplo2.describe())#

#mascara
mask = sEjemplo2 >sEjemplo2.mean()
print (sEjemplo2[mask])


#grafica de una serie
fig = plt.figure()
sEjemplo2.plot()
sEjemplo2.plot(kind = 'bar', color = 'k', alpha = .8)


# %%